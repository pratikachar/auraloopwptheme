<?php
/**
 * Aura Loop Theme Functions
 * Author: colorgraphicz
 */

// ==============================
// THEME SETUP
// ==============================
function aura_loop_setup() {
    // Theme supports
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 120,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets',
    ));
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('automatic-feed-links');

    // Register navigation menus
    register_nav_menus(array(
        'primary' => esc_html__('Primary Menu (Header)', 'aura-loop'),
        'footer'  => esc_html__('Footer Menu', 'aura-loop'),
    ));

    // Set thumbnail size
    set_post_thumbnail_size(640, 400, true);
    add_image_size('aura-loop-card', 640, 400, true);
}
add_action('after_setup_theme', 'aura_loop_setup');

// ==============================
// ENQUEUE SCRIPTS & STYLES
// ==============================
function aura_loop_scripts() {
    // Google Fonts
    wp_enqueue_style('aura-loop-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;900&family=Inter:wght@300;400;500&display=swap', array(), null);

    // Theme stylesheet
    wp_enqueue_style('aura-loop-style', get_stylesheet_uri(), array('aura-loop-fonts'), wp_get_theme()->get('Version'));

    // Theme JavaScript
    wp_enqueue_script('aura-loop-theme', get_template_directory_uri() . '/assets/js/theme.js', array('jquery'), wp_get_theme()->get('Version'), true);
    wp_localize_script('aura-loop-theme', 'auraml_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}
add_action('wp_enqueue_scripts', 'aura_loop_scripts');

// ==============================
// REGISTER WIDGET AREAS
// ==============================
function aura_loop_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Blog Sidebar', 'aura-loop'),
        'id'            => 'sidebar-1',
        'description'   => esc_html__('Add widgets for the blog sidebar.', 'aura-loop'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Column 1', 'aura-loop'),
        'id'            => 'footer-1',
        'description'   => esc_html__('First footer widget column.', 'aura-loop'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="footer-col-title">',
        'after_title'   => '</div>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Column 2', 'aura-loop'),
        'id'            => 'footer-2',
        'description'   => esc_html__('Second footer widget column.', 'aura-loop'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="footer-col-title">',
        'after_title'   => '</div>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Column 3', 'aura-loop'),
        'id'            => 'footer-3',
        'description'   => esc_html__('Third footer widget column.', 'aura-loop'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="footer-col-title">',
        'after_title'   => '</div>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Column 4', 'aura-loop'),
        'id'            => 'footer-4',
        'description'   => esc_html__('Fourth footer widget column.', 'aura-loop'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="footer-col-title">',
        'after_title'   => '</div>',
    ));
}
add_action('widgets_init', 'aura_loop_widgets_init');

// ==============================
// CUSTOM WALKER FOR PRIMARY NAV
// ==============================
class Aura_Loop_Walker_Nav_Menu extends Walker_Nav_Menu {
    public function start_lvl(&$output, $depth = 0, $args = null) {
        $indent  = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"sub-menu\">\n";
    }
}

// ==============================
// CUSTOM BODY CLASSES
// ==============================
function aura_loop_body_classes($classes) {
    if (is_singular()) {
        $classes[] = 'singular';
    }
    if (is_active_sidebar('sidebar-1')) {
        $classes[] = 'has-sidebar';
    }
    return $classes;
}
add_filter('body_class', 'aura_loop_body_classes');

// ==============================
// EXCERPT LENGTH
// ==============================
function aura_loop_excerpt_length($length) {
    return 25;
}
add_filter('excerpt_length', 'aura_loop_excerpt_length');

function aura_loop_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'aura_loop_excerpt_more');

// ==============================
// CUSTOM COMMENT CALLBACK
// ==============================
function aura_loop_comment($comment, $args, $depth) {
    $tag = ('div' === $args['style']) ? 'div' : 'li';
    ?>
    <<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class('comment', $comment); ?>>
        <article id="div-comment-<?php comment_ID(); ?>" class="comment-body">
            <div class="comment-meta">
                <?php printf('<span class="fn">%s</span>', get_comment_author_link($comment)); ?>
                <span class="comment-date"> &middot; <?php echo get_comment_date('', $comment); ?></span>
            </div>
            <?php if ('0' === $comment->comment_approved) : ?>
                <p class="comment-awaiting-moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'aura-loop'); ?></p>
            <?php endif; ?>
            <div class="comment-content">
                <?php comment_text(); ?>
            </div>
            <div class="comment-reply">
                <?php
                comment_reply_link(array_merge($args, array(
                    'reply_text' => esc_html__('Reply', 'aura-loop'),
                    'depth'      => $depth,
                    'max_depth'  => $args['max_depth'],
                )));
                ?>
            </div>
        </article>
    <?php
}

// ==============================
// FORM HANDLER (AJAX)
// ==============================
function aura_loop_handle_contact() {
    $name    = isset($_POST['name'])     ? trim($_POST['name'])     : '';
    $email   = isset($_POST['email'])    ? trim($_POST['email'])    : '';
    $plan    = isset($_POST['plan'])     ? trim($_POST['plan'])     : '';
    $vision  = isset($_POST['vision'])   ? trim($_POST['vision'])   : '';
    $captcha = isset($_POST['captcha'])  ? trim($_POST['captcha'])  : '';
    $cap1    = isset($_POST['cap1'])     ? intval($_POST['cap1'])   : 0;
    $cap2    = isset($_POST['cap2'])     ? intval($_POST['cap2'])   : 0;
    $cap_token = isset($_POST['cap_token']) ? trim($_POST['cap_token']) : '';

    if (empty($name) || empty($email)) {
        wp_send_json_error(array('msg' => 'Please fill in all required fields.'));
    }

    if (! is_email($email)) {
        wp_send_json_error(array('msg' => 'Please provide a valid email address.'));
    }

    $expected_answer = $cap1 + $cap2;
    $expected_token = wp_hash($expected_answer . '|aura-loop-captcha');

    if ((int) $captcha !== $expected_answer || $cap_token !== $expected_token) {
        wp_send_json_error(array('msg' => 'Incorrect captcha answer. Please try again.'));
    }

    $to = get_option('admin_email');
    $subject = "Aura Loop — New Membership Inquiry from $name";
    $body = "Name: $name\nEmail: $email\nPlan: " . ($plan ?: 'Not specified') . "\nVision: " . ($vision ?: 'Not provided') . "\n";
    $headers = array(
        'From: Aura Loop <contact@auraloop.colorgraphicz.in>',
        'Reply-To: ' . $email,
        'Content-Type: text/plain; charset=UTF-8',
    );

    $sent = wp_mail($to, $subject, $body, $headers);

    if ($sent) {
        wp_send_json_success(array('msg' => 'Thank you! Your request has been received. Welcome to the Loop.'));
    } else {
        wp_send_json_error(array('msg' => 'Server error. Please try again or contact us directly.'));
    }
}
add_action('wp_ajax_nopriv_aura_loop_contact', 'aura_loop_handle_contact');
add_action('wp_ajax_aura_loop_contact', 'aura_loop_handle_contact');

// ==============================
// SEARCH FORM
// ==============================
function aura_loop_search_form($form) {
    $form = '<form role="search" method="get" class="search-form" action="' . esc_url(home_url('/')) . '" style="max-width:400px; margin:0 auto 3rem; display:flex; gap:0.5rem; padding:0 5rem;">
        <input type="search" class="search-field" placeholder="' . esc_attr__('Search...', 'aura-loop') . '" value="' . get_search_query() . '" name="s" style="flex:1; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.12); border-radius:24px; padding:0.8rem 1.2rem; font-family:var(--font-b); font-size:0.85rem; color:var(--white);">
        <button type="submit" class="search-submit btn-mint" style="padding:0.8rem 1.5rem; border-radius:24px; border:none;">' . esc_html__('Search', 'aura-loop') . '</button>
    </form>';
    return $form;
}
add_filter('get_search_form', 'aura_loop_search_form');
